<?php
ob_clean();
require_once '../PHPWord.php';
$PHPWord = new PHPWord();
$section = $PHPWord->createSection();

$header = $section->createHeader();

$table = $header->addTable();
$table->addRow();
$table->addCell(4500)->addText('重庆金算盘软件有限公司销售单报表', array('align' => 'center'));
$table->addCell(4500)->addImage('_mars.jpg', array('width' => 30, 'height' => 30, 'align' => 'right'));
/*
// Add text elements
$section->addText('Hello World!');
$section->addText('Hello World!');
$section->addTextBreak(2);

$section->addText('I am inline styled.', array('name'=>'Verdana', 'color'=>'006699'));
$section->addTextBreak(2);

$PHPWord->addFontStyle('rStyle', array('bold'=>true, 'italic'=>true, 'size'=>16));
$PHPWord->addParagraphStyle('pStyle', array('align'=>'center', 'spaceAfter'=>100));
$section->addText('I am styled by two style definitions.', 'rStyle', 'pStyle');
$section->addText('I have only a paragraph style definition.', null, 'pStyle');
*/
// Add table
$table = $section->addTable();
$table->addRow();
$table->addCell(20)->addText("客户名称：");
$table->addCell(1000)->addText("kljkjlj");

$table->addRow();
$table->addCell(20)->addText("分支机构：");
$table->addCell(700)->addText("xx");
$table->addCell(20)->addText("单据编号：");
$table->addCell(700)->addText("xx");

$table->addRow();
$table->addCell(20)->addText("代 理 商：");
$table->addCell(700)->addText("xx");

$table->addRow();
$table->addCell(20)->addText("客户类型：");
$table->addCell(700)->addText("老客户/新客户");
$table->addCell(20)->addText("业务日期：");
$table->addCell(700)->addText("xxx");

$table->addRow();
$table->addCell(20)->addText("订货类别：");
$table->addCell(700)->addText("xx");
$table->addCell(20)->addText("结算金额：");
$table->addCell(700)->addText("xx");

$table->addRow();
$table->addCell(20)->addText("开票信息：");
$table->addCell(750)->addText("描述描述描述描述描述描述描述描述描述描述描述描述描述");

$table->addRow();
$table->addCell(20)->addText("描述：");
$table->addCell(700)->addText("开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息开票信息");

$PHPWord->addFontStyle('rStyle', array('bold'=>true, 'italic'=>true, 'size'=>16));
$table->addRow();
$table->addCell(20)->addText("产品信息", 'rStyle', null);

$table->addRow();
$table->addCell(20)->addText("序号");

$table->addCell(20)->addText("产品名称");

$table->addCell(20)->addText("数量");

$table->addCell(20)->addText("价格");

$table->addCell(20)->addText("折扣");

$table->addCell(20)->addText("税");

$table->addCell(20)->addText("合计");

/** foreach  Start**/
$table->addRow();
$table->addCell(20)->addText("序号");

$table->addCell(20)->addText("产品名称");

$table->addCell(20)->addText("数量");

$table->addCell(20)->addText("价格");

$table->addCell(20)->addText("折扣");

$table->addCell(20)->addText("税");

$table->addCell(20)->addText("合计");

/** foreach  End**/

$table->addRow();
$table->addCell(20)->addText("");

$table->addCell(20)->addText("总计");

$table->addCell(20)->addText("40");

$table->addCell(20)->addText("4000");

$table->addCell(20)->addText("0");

$table->addCell(20)->addText("0");

$table->addCell(20)->addText("4000");

//$section->addTextBreak(5);

$table->addRow();
$table->addCell(20)->addText("制单人：");

$table->addCell(20)->addText("丁婧");

$table->addCell(20)->addText("检验：");

$table->addCell(20)->addText("4000");

$table->addCell(20)->addText("业务员：");

$table->addCell(20)->addText("0");

$table->addCell(20)->addText("打印日期：");

$table->addCell(20)->addText("4000");




$footer = $section->createFooter();
$footer->addPreserveText('第 {PAGE}页， 共 {NUMPAGES}页', array('align' => 'left'));
$footer->addPreserveText('地址: 金算盘总公司， 重庆市北部新区星光大道62号海王星科技大厦三区5层', array('align' => 'right'));
$objWriter = PHPWord_IOFactory::createWriter($PHPWord, 'Word2007');
$objWriter->save('Sales.docx');
