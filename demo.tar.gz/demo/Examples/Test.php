<?php
require_once '../PHPWord.php';
//require_once '../libs/PHPWord/PHPWord/IOFactory.php';

//require_once '../../config.php';
// require_once '../common/conn.php';

// New Word Document
$PHPWord = new PHPWord();

/**********文本格式的word text.php************/
// New portrait section

//逗号 分割字符串
$arr = isset($_REQUEST['arr']) ? $_REQUEST : '';
$a = explode(',',$arr);
//echo $arr;
date_default_timezone_set("Asia/Shanghai");//设置一个时区
$tm=date('Y-m-d H:i:s');
//exit($tm);
/**********前多日雨量*********/
if(in_array('1', $a, TRUE)){
$section = $PHPWord->createSection();
$PHPWord->addFontStyle('rStyle', array('bold'=>false, 'italic'=>false, 'size'=>16));
$PHPWord->addParagraphStyle('pStyle', array('align'=>'center', 'spaceAfter'=>100));
$c = "前三日雨量报表";
$section->addText($c, 'rStyle', 'pStyle');

$styleTable = array('borderSize'=>6, 'borderColor'=>'006699', 'cellMargin'=>80);
$styleFirstRow = array('borderBottomSize'=>18, 'borderBottomColor'=>'0000FF', 'bgColor'=>'66BBFF');

// Define cell style arrays
$styleCell = array('valign'=>'center');
// Define font style for first row
$fontStyle = array('bold'=>true, 'align'=>'center');
//设置标题
$PHPWord->addFontStyle('rStyle', array('bold'=>true, 'italic'=>true, 'size'=>16));
$PHPWord->addParagraphStyle('pStyle', array('align'=>'center', 'spaceAfter'=>100));

// Add table style
$PHPWord->addTableStyle('myOwnTableStyle', $styleTable, $styleFirstRow);

// Add table
$table = $section->addTable('myOwnTableStyle');

// Add row设置行高
$table->addRow(500);

$table->addCell(2300, $styleCell)->addText('站码', $fontStyle);
$table->addCell(2300, $styleCell)->addText('站名', $fontStyle);
$table->addCell(2300, $styleCell)->addText('雨量', $fontStyle);
$table->addCell(2300, $styleCell)->addText('水文站监测类型', $fontStyle);

$conn = mssql_connect($config['mssql']['host'],$config['mssql']['user'],$config['mssql']['password']);
mssql_select_db($config['mssql']['dbname'],$conn);

$stm = date('Y-m-d H:i:s',strtotime('-3 days'));
$sql = "EXEC HNOW05_GETPPSPACE '','','".$stm."',1,1";
$res=mssql_query($sql);

while($arr = mssql_fetch_array($res)){
//echo $arr["STCD"]."</br>";
$table->addRow();
$table->addCell(2300)->addText($arr["STCD"]);
$table->addCell(2300)->addText($arr["STNM"]);
$table->addCell(2300)->addText($arr["P"]);
if($arr["STTP"] == 'MM'){
$table->addCell(2300)->addText('气象站');
}else if($arr["STTP"] == 'BB'){
$table->addCell(2300)->addText('蒸发站');
}else if($arr["STTP"] == 'DD'){
$table->addCell(2300)->addText('堰闸水文站');
}else if($arr["STTP"] == 'TT'){
$table->addCell(2300)->addText('落潮位站');
}else if($arr["STTP"] == 'DP'){
$table->addCell(2300)->addText('泵站');
}else if($arr["STTP"] == 'SS'){
$table->addCell(2300)->addText('墒情站');
}else if($arr["STTP"] == 'PP'){
$table->addCell(2300)->addText('雨量站');
}else if($arr["STTP"] == 'ZZ'){
$table->addCell(2300)->addText('河道水位水文站');
}else if($arr["STTP"] == 'RR'){
$table->addCell(2300)->addText('水库水文站');
}else if($arr["STTP"] == 'ZG'){
$table->addCell(2300)->addText('地下水站');
}else if($arr["STTP"] == 'ZB'){
$table->addCell(2300)->addText('分洪水位站');
}
}
$section->addTextBreak(2);
}else{

}

/******地质灾害*******/
if(in_array('3', $a, TRUE)){
$section = $PHPWord->createSection();
$PHPWord->addFontStyle('rStyle', array('bold'=>false, 'italic'=>false, 'size'=>16));
$PHPWord->addParagraphStyle('pStyle', array('align'=>'center', 'spaceAfter'=>100));
$c = "地质灾害";
$section->addText($c, 'rStyle', 'pStyle');

$content="根据市气象局未来24小时降雨预报和市水利局实时降雨数据，市国土资源局进行了地质灾害预报，请有关部门关注

实时预警信息，做好地质灾害防范工作";
$section->addText($content);
// Add image elements
$section->addImage("images/image001.jpg", array('width'=>600, 'height'=>480, 'align'=>'center'));
}else{

}
// Save File
$fileName = "word报表".date("YmdHis");
header("Content-type: application/vnd.ms-word");
header("Content-Disposition:attachment;filename=".$fileName.".docx");
header('Cache-Control: max-age=0');
$objWriter = PHPWord_IOFactory::createWriter($PHPWord, 'Word2007');
$objWriter->save('php://output');
